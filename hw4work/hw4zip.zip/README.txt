Ben Knight
student id = 5662450
student email = knigh501@umn.edu

- necessary libraries/packages are numpy, random
matplotlib.pyplot and gymnasium. 

to run taxi_sarsa.py simply enter the command: 
    -> python taxi_sarsa.py 

to run taxi_qlearning.py simply enter the command: 
    -> python3 taxi_qlearning.py 

to run multiagent_learning.py simply enter the command: 
    -> python3 multiagent_learning.py